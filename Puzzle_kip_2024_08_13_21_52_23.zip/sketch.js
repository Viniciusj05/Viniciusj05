function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);     
}
function draw() {
    background("black");
    
    rect(0, 10, 100, 150);
}
function draw() {
    background("black");

    fill("white");
    rect(0, 10, 100, 150);
}
function draw() {
    background("black");
    
    stroke("blue") 
    fill("white") 
    rect(0, 10, 100, 150)
}
function draw() {
  background(220);
  
  stroke("blue");
  fill("white");
  rect(mouseX, mouseY, 100, 150);
}
function draw() {
  background(220);
  
  stroke("blue");
  fill("white");
  
  console.log(mouseIsPressed);
  rect(mouseX, mouseY, 100, 150);
}
function setup() {
  // cria uma tela de 400px de largura por 400px de altura
  createCanvas(400, 400);
}
function setup() {
  createCanvas(400, 400);
  background("black")
}

function draw() {
  stroke("white");
  fill("white");
  
  
  if (mouseIsPressed) {
    rect(mouseX, mouseY, 20, 35);
  }
}
